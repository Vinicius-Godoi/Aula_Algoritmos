// exemplo de matriz
#include <iostream>
#include <conio.h>
using namespace std;

main() {
	setlocale (LC_ALL, "Portuguese");
    int matA[5][7]; // cria matriz 5 linhas x 7 colunas (35)
    
    // la�o que controla linhas
    for (int lin=0; lin<5; lin++){
        
         cout << "linha: " << lin << endl;
        
        // la�o que controla colunas
        for (int col=0; col<7; col++){
            
            cout << "  coluna: " << col << endl;
            
            matA[lin][col] = col + lin;  // preenche o elemento
    
        }
    }
    
    // mostra a matriz preenchida
    for (int lin=0; lin<5; lin++){
        // la�o que controla colunas
        for (int col=0; col<7; col++){
            cout << matA[lin][col] << " | ";
        }
        cout << endl;
    }

	getch();
}
