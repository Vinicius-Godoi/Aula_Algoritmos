/*
Crie uma matriz de 10 x 10 posi��es e preencha seus 
elementos com n�meros inteiros digitados. Apure e mostre:	
A soma de todos os elementos da matriz
A soma dos elementos da 1� linha
A soma dos elementos da 2� coluna
*/

#include <iostream>
#include <conio.h>
using namespace std;

// altere para testar
const int linha=100;
const int coluna=100;

main() {
	setlocale (LC_ALL, "Portuguese");
    int mat[linha][coluna];
    int soma=0, somalinha1=0, somacoluna2=0;    
    // input dos n�meros
    for (int lin=0; lin<linha; lin++) {
        for (int col=0; col<coluna; col++){
            cout << "Informe o valor de " << lin << "," << col <<": ";
            cin >> mat[lin][col];
        }
     }    

     // apura��o dos valores
     for (int lin=0; lin<linha; lin++){
         for (int col=0; col<coluna; col++) {
             soma = soma + mat[lin][col];
             // verifica se a linha � a primeira (0)
             if (lin==0) {
                somalinha1 = somalinha1 + mat[lin][col];
             } 
             // verifica se a coluna � a 2a (1)
             if (col==1) {
                somacoluna2 = somacoluna2 + mat[lin][col];  
             }  
         }
     }
     
     cout << "Resultados...." << endl;
     cout << "Soma: " << soma << endl;
     cout << "Soma 1� Linha: " << somalinha1 << endl;
     cout << "Soma 2� Coluna: "<< somacoluna2 << endl;
   	 getch();
}
